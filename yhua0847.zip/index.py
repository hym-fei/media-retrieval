import math
import json
from collections import defaultdict, Counter
from utils import preprocess

class InvertedIndex:
    def __init__(self):
        self.index = defaultdict(list)
        self.doc_lengths = {}
        self.doc_freq = defaultdict(int)
        self.documents = {}

    def build_index(self, doc_list):
        for doc in doc_list:
            doc_id = doc["id"]
            tokens = preprocess(doc["content"])
            self.documents[doc_id] = doc["content"]
            self.doc_lengths[doc_id] = len(tokens)
            term_counts = Counter(tokens)
            for term, freq in term_counts.items():
                self.index[term].append((doc_id, freq))
                self.doc_freq[term] += 1

    def tfidf_score(self, query_terms, k=5):
        scores = defaultdict(float)
        N = len(self.documents)
        for term in query_terms:
            postings = self.index.get(term, [])
            df = self.doc_freq.get(term, 0)
            if df == 0:
                continue
            idf = math.log(N / df)
            for doc_id, tf in postings:
                scores[doc_id] += tf * idf
        ranked_docs = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        return ranked_docs[:k]  # 返回 [(doc_id, score), ...]

    def get_document(self, doc_id):
        return self.documents.get(doc_id, "")

    def load_json(self, filepath):
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data["documents"]
