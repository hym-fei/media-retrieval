from utils import preprocess

class QueryParser:
    def __init__(self, index_terms):
        self.terms = index_terms

    def expand_wildcard(self, token):
        if token.endswith("*"):
            prefix = token[:-1]
            return [term for term in self.terms if term.startswith(prefix)]
        return [token]

    def parse_boolean_query(self, query):
        tokens = query.upper().replace("(", " ( ").replace(")", " ) ").split()
        output = []
        stack = []
        precedence = {"NOT": 3, "AND": 2, "OR": 1}
        for token in tokens:
            if token == "(":
                stack.append(token)
            elif token == ")":
                while stack and stack[-1] != "(":
                    output.append(stack.pop())
                stack.pop()
            elif token in precedence:
                while (stack and stack[-1] in precedence and
                       precedence[stack[-1]] >= precedence[token]):
                    output.append(stack.pop())
                stack.append(token)
            else:
                output.append(token)
        while stack:
            output.append(stack.pop())
        return output