import argparse
import json
from index import InvertedIndex
from query_parser import QueryParser
from utils import preprocess

def evaluate_rpn(rpn_query, index):
    stack = []
    all_docs = set(index.documents.keys())
    for token in rpn_query:
        if token == "AND":
            b = stack.pop()
            a = stack.pop()
            stack.append(a & b)
        elif token == "OR":
            b = stack.pop()
            a = stack.pop()
            stack.append(a | b)
        elif token == "NOT":
            a = stack.pop()
            stack.append(all_docs - a)
        else:
            sub_terms = parser.expand_wildcard(token.lower())
            docs = set()
            for term in sub_terms:
                docs |= set(doc_id for doc_id, _ in index.index.get(term, []))
            stack.append(docs)
    return stack[0] if stack else set()

if __name__ == "__main__":
    parser_cli = argparse.ArgumentParser()
    parser_cli.add_argument("--query", type=str, required=True)
    parser_cli.add_argument("--k", type=int, default=5)
    args = parser_cli.parse_args()

    index = InvertedIndex()
    documents = index.load_json("data/docs.json")
    index.build_index(documents)

    parser = QueryParser(index.index.keys())
    rpn = parser.parse_boolean_query(args.query)
    filtered_doc_ids = evaluate_rpn(rpn, index)

    ranking = index.tfidf_score(preprocess(args.query), k=len(index.documents))


    filtered_ranking = [item for item in ranking if item[0] in filtered_doc_ids]

    formatted_results = []
for rank_index, (doc_id, score) in enumerate(filtered_ranking[:args.k]):
    formatted_results.append({
        "rank": rank_index + 1,
        "document_id": str(doc_id),
        "score": round(score, 4)
    })

output = {
    "k": args.k,
    "docs": formatted_results
}
print(json.dumps(output, indent=2))
